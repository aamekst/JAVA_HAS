package br.com.has.beans;

public class Aluno extends Pessoa {
	
	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	private String curso;
	

}
